from django.apps import AppConfig


class CampusConfig(AppConfig):
    name = 'campus'
