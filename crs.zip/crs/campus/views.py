from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import login,authenticate,logout
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import Student_SignUpForm,UsdForm,dispstuForm,company_SignUpForm,ccdForm,jobposForm
from django.contrib.auth.models import Group, User
from django.contrib.auth import authenticate
from django.http import HttpResponse
from django.views.generic.edit import CreateView
from campus.models import stu_details,comp_details,job_pos,applied_jobs
from django.core.mail import EmailMessage
from django.contrib.auth.decorators import login_required, user_passes_test
from django.views.generic import TemplateView
from django.utils.decorators import method_decorator

# Create your views here
def  student_login(request):   
    if request.user.is_authenticated and request.user.groups.filter(name='student').exists():
        return render(request,'campus/stulog.html')
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            if request.user.groups.filter(name='student').exists():
                username = request.POST.get("username")
                print("User Name : ", username)
                request.session["username"] = username
                return render(request, 'campus/stulog.html', {'form': form})
            else:
                logout(request)
                return render(request, 'campus/student_login.html', {'form': form})
        else:
            return render(request, 'campus/student_login.html', {'form': form})
    else:
        form = AuthenticationForm()
        return render(request, 'campus/student_login.html', {'form': form})

def home(request):
    return render(request,'campus/home.html')

def pagelogout(request):
        logout(request)
        return redirect('http://127.0.0.1:8000/')

def student_register(request):
    if request.method == 'POST':
        form = Student_SignUpForm(request.POST)
        if form.is_valid():
            user=form.save()
            group = Group.objects.get(name='student')
            user.groups.add(group)
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            print("User : ", user)
            request.session["username"]=username

            return redirect('http://127.0.0.1:8000/student/student_login/')
        else:
            return render(request, 'campus/register.html', {'form': form})
    else:
        form =Student_SignUpForm()
        return render(request, 'campus/register.html', {'form': form})

def usd(request):
    if request.user.is_authenticated and request.user.groups.filter(name='student').exists():
        if request.method == "POST":
            form = UsdForm(request.POST)
            stu_username = request.user.username
            print("Stu User Name ", stu_username)
            #if form.is_valid():
            stu_username = request.user.username
            print("Stu User Name ", stu_username)
            try:
                stu_obj = stu_details.objects.get(username=stu_username)
            except stu_details.DoesNotExist:
                stu_obj = stu_details(username=stu_username)

            print("Fathers Name : ", request.POST.get('fathers_name'))
            print("Mothers Name : ", request.POST.get('mothers_name'))

            stu_obj.sop = request.POST.get('sop')
            stu_obj.phone_number = request.POST.get('phone_number')
            stu_obj.dob = request.POST.get('dob')
            stu_obj.email = request.POST.get('email')
            stu_obj.languages = request.POST.get('languages')
            stu_obj.certifications_count = request.POST.get('certifications_count')
            stu_obj.internship = request.POST.get('internship')
            stu_obj.class_12_percentage = request.POST.get('class_12_percentage')
            stu_obj.class_10_cgpa = request.POST.get('class_10_cgpa')
            stu_obj.branch = request.POST.get('branch')
            stu_obj.cgpa_Masters = request.POST.get('cgpa_Masters')
            stu_obj.place = request.POST.get('place')
            stu_obj.gender = request.POST.get('gender')
            stu_obj.fathers_name = request.POST.get('fathers_name')
            stu_obj.mothers_name = request.POST.get('mothers_name')
            stu_obj.name = request.POST.get('name')

            stu_obj.save()

            return render(request, 'campus/stulog.html')
        else:
            stu = request.user.username
            print("Stu : ", stu)
            post = stu_details.objects.filter(username=stu).first()
            if post is not None:
                form=UsdForm()
                db=post.dob
                e=post.email
                l=post.languages
                cc=post.certifications_count
                i=post.internship
                c12=post.class_12_percentage
                c10=post.class_10_cgpa
                b=post.branch
                cb=post.cgpa_Masters
                p=post.place
                g=post.gender
                fn=post.fathers_name
                mn=post.mothers_name
                name=post.name
                ph=post.phone_number
                sop=post.sop
                print("Sop : ", sop)
                context={'form': form, 'sop':sop, 'ph':ph, 'db': db,"e":e,"l":l,"cc":cc,"i":i,"c12":c12,"c10":c10,"b":b,"cb":cb,"p":p,"g":g,"fn":fn,"mn":mn,"name":name}
                #context.save()
                return render(request, 'campus/usd.html',context)
        """
        else:
            form=UsdForm()
            context={'form': form}
            return render(request, 'campus/usd.html',context)
        """
        ''' else:
                stu = request.user.username
                post = stu_details.objects.filter(username=stu).first()
                if post.exists():
                    post = post[0]
                else:
                    x=str(x)
                    y = post[0].phone_number
                    print(x,y,post)
                    form=UsdForm()
                    db=post[0].dob
                    e=post[0].email
                    l=post[0].languages 
                    cc=post[0].certifications_count
                    i=post[0].internship
                    c12=post[0].class_12_percentage
                    c10=post[0].class_10_cgpa
                    b=post[0].branch
                    cb=post[0].cgpa_Masters
                    p=post[0].place
                    g=post[0].gender
                    fn=post[0].fathers_name
                    mn=post[0].mothers_name
                    name=post[0].name
                    context={'form': form,'x':x,'y':y,'db': db,"e":e,"l":l,"cc":cc,"i":i,"c12":c12,"c10":c10,"b":b,"cb":cb,"p":p,"g":g,"fn":fn,"mn":mn,"name":name}
                    return render(request, 'campus/usd.html',context)

    else:'''
        return render(request, 'campus/usd.html')
    else:
        return HttpResponse("<h1>you are not logged in</h1>")


def dispstu(request):
    if request.user.is_authenticated and request.user.groups.filter(name='student').exists():
        stu = request.user.username
        post = stu_details.objects.filter(username=stu)
        form=dispstuForm()
        return render(request, 'campus/dispstu.html', {'form': form, 'post': post})
    else:
        return HttpResponse("<h1>u r not logged in</h1>")

'''def dispstu(request):
    username = request.session["username"]
    print("UserName is Display Profile : " , request.session["username"])
    if request.user.is_authenticated:
        stu = request.user.username
        post = User.objects.get(username=username)
        details = stu_details.objects.get(username=username)
        print("Reg Num : ", post.first_name)
        print("Student Details : ", details.fathers_name)

        #print("Student Data : ", data.email)
        #student = request.user.groups.filter(username=username)
        #print("Student : ", student)
        #post = stu_details.objects.filter(username=username)
        #print("Student Details : ", post)
        form=dispstuForm()
        return render(request, 'campus/dispstu.html', {'uname': post.username,
                                                       'fname': post.first_name,
                                                       'lname': post.last_name,
                                                       'per': details})
    else:
        return HttpResponse("<h1>u r not logged in</h1>")'''



def company_register(request):
    if request.method == 'POST':
        form = company_SignUpForm(request.POST)
        if form.is_valid():
            user=form.save()
            group = Group.objects.get(name='company')
            user.groups.add(group)
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            a=comp_details()
            a.username=request.POST.get('username')
            a.company_name=request.POST.get('company_name')
            a.email=request.POST.get('email')
            a.est_year=request.POST.get('est_year')
            a.type=request.POST.get('type')
            a.about=request.POST.get('about')
            a.hr_name=request.POST.get('hr_name')
            a.hr_phn=request.POST.get('hr_phn')
            a.headquaters=request.POST.get('headquaters')
            a.save()
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('http://127.0.0.1:8000/')
        else:
            return render(request, 'campus/register1.html', {'form': form})

    else:
        form =company_SignUpForm()
        return render(request, 'campus/register1.html', {'form': form})



def  company_login(request):
    if request.user.is_authenticated and request.user.groups.filter(name='company').exists():
        return render(request,'campus/comlog.html')
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            if request.user.groups.filter(name='company').exists():
             return render(request, 'campus/comlog.html', {'form': form})
            else:
                logout(request)
                return render(request, 'campus/company_login.html', {'form': form})
        else:
            return render(request, 'campus/company_login.html', {'form': form})
    else:
        form = AuthenticationForm()
        return render(request, 'campus/company_login.html', {'form': form})




def ccd(request):
 if  request.user.is_authenticated and request.user.groups.filter(name='company').exists():
    if request.method == "POST":
            form=ccdForm(request.POST)
            if form.is_valid():
                stu = request.user.username
                post = comp_details.objects.filter(username=stu)
                x= request.POST.get('hr_name')
                y=request.POST.get('hr_phn')
                z=request.POST.get('about')
                j=post[0]
                j.hr_name =x
                j.hr_phn = y
                j.about=z
                j.save()
                return render(request, 'campus/comlog.html')

    else:
        stu = request.user.username
        post = comp_details.objects.filter(username=stu)
        x = post[0].hr_name
        x=str(x)
        y = post[0].hr_phn
        z=post[0].about
        form=ccdForm()
        return render(request, 'campus/ccd.html', {'form': form,'x':x,'y':y,'z':z})
 else:
     return HttpResponse("<h1>u r not logged in</h1>")



def jobpos(request):
    if request.user.is_authenticated and request.user.groups.filter(name='company').exists():
        if request.method == "POST":
            form = jobposForm(request.POST)
            if form.is_valid():
                    model_instance = form.save(commit=False)
                    model_instance.save()
                    return render(request,'campus/comlog.html')
            else:
                return render(request, 'campus/jobpos.html', {'form': form})
        else:
            form = jobposForm()
            x = request.user.username
            y = comp_details.objects.filter(username=x)
            y = str(y[0].company_name)
            y=y.split()
            y1=""
            for i in y:
                y1=y1+"_"+i
            y1=y1[1:len(y1)]
            print(y)

            return render(request, 'campus/jobpos.html', {'form': form,'x':x,'y':y1})
    else:
        return HttpResponse("<h1>u r not logged in</h1>")

def jd(request):
    if request.user.is_authenticated and request.user.groups.filter(name='company').exists():
        if request.method == "POST":
                    s=""
                    print("hiiiiiii")
                    book=job_pos.objects.filter(job_id=request.POST.get("job_id"))
                    print(len(book))
                    if(len(book)!=1):
                        s="wrong job id try again"
                        return render(request, 'campus/jd.html',{'s':s})
                    book=book[0]
                    book.designation=request.POST.get("designation")
                    book.salary=request.POST.get("salary")
                    book.bond_years=request.POST.get("bond_years")
                    book.MCA=request.POST.get("MCA")
                    book.MBA=request.POST.get("MBA")
                    book.MSC=request.POST.get("MSC")
                    book.save()
                    return render(request,'campus/comlog.html',{'s':s})
        else:
            x = request.user.username
            y = comp_details.objects.filter(username=x)
            y = str(y[0].company_name)
            y=y.split()
            y1=""
            for i in y:
                y1=y1+"_"+i
            y1=y1[1:len(y1)]
            return render(request, 'campus/jd.html', {'x':x,'y':y1})
    else:
        return HttpResponse("<h1>u r not logged in</h1>")


def deletevacan(request):
    if request.user.is_authenticated and request.user.groups.filter(name='company').exists():
        if request.method == "POST":
                    s=""
                    book=job_pos.objects.filter(job_id=request.POST.get("jobid"))
                    print(len(book))
                    if(len(book)!=1):
                        s="wrong job id try again"
                        return render(request, 'campus/jobdelete.html',{'s':s})
                    applied_jobs.objects.filter(job_id=book[0]).delete()
                    book[0].delete()
                    s="job deleted succssefully"
                    return render(request,'campus/comlog.html',{'msg':s})
        else:
            return render(request, 'campus/jobdelete.html')
    else:
        return HttpResponse("<h1>u r not logged in</h1>")

def viewpos(request):
    if request.user.is_authenticated and request.user.groups.filter(name='company').exists():
        x = request.user.username
        y = job_pos.objects.filter(username=x)
        s=""
        print(y)
        if(len(y)==0):
            s="no vacancies posted"
        return render(request, 'campus/viewpos.html',{'y':y,'s':s})
    else:
        return HttpResponse("<h1>u r not logged in</h1>")



def applyjob(request):
    if request.user.is_authenticated and request.user.groups.filter(name='student').exists():
      s=""
      y=[]
      if request.method == "POST":
        print("hi")
        sal=request.POST.get("salary")
        bon=request.POST.get("years")
        x = request.user.username
        b = stu_details.objects.filter(username=x)
        y = job_pos.objects.filter(salary__gte=sal, bond_years__lte=bon ).order_by('salary')
        if b.exists():
            b = str(b[0].branch)
        #b = str(b[0].branch)
        """
        print(sal,bon,b)
        if(b=="Masters / Bachelors "):
            y = job_pos.objects.filter(salary__gte=sal,bond_years__lte=bon,information_technology="yes").order_by('salary')
        if (b == "MCA"):
            y = job_pos.objects.filter(salary__gte=sal, bond_years__lte=bon,cse="yes").order_by('salary')
        if (b == "MBA"):
            y = job_pos.objects.filter(salary__gte=sal, bond_years__lte=bon,mech="yes").order_by('salary')
        if (b == "MSC"):
            y = job_pos.objects.filter(salary__gte=sal, bond_years__lte=bon,civil="yes").order_by('salary')
        """
        print(y)
        if(len(y)==0):
            s="no vacancies for this preference"
            print("failed",s)
            return render(request, 'campus/applyjob.html',{'s':s})
        else:
            return render(request, 'campus/applyjob.html', {'y': y, 's': s})
      else:
          data = job_pos.objects.all()
          print("Data : ", data)
          return render(request, 'campus/applyjob.html', { 'y':data,'s': s})
    else:
        return HttpResponse("<h1>you are not logged in</h1>")


def apply(request,opt):
    if request.user.is_authenticated and request.user.groups.filter(name='student').exists():
        if request.method=="POST":
            x=request.user.username
            print(x)
            y=job_pos.objects.filter(job_id=opt)[0].username
            job=applied_jobs()
            job.student_id=x
            job.company_id=y
            job.job_id=opt
            job.save()
            return HttpResponse("<h1>you have applied succesfully... all the best</h1>")


        else:
            c=job_pos.objects.filter(job_id=opt)[0].username
            print(c)
            x=comp_details.objects.filter(username=c)
            print(x)
            return render(request,'campus/compdisp.html',{'post':x[0]})

    else:
        return HttpResponse("<h1>you are not logged in</h1>")


def selectstu(request):
    y=[]
    s=""
    x = applied_jobs.objects.all()
    print("Applied Jobs : ", x)

    for i in x:
        print(i.student_id)

    if request.user.is_authenticated and request.user.groups.filter(name='company').exists():
        for i in x:
            b = stu_details.objects.filter(username=i.student_id)
            if (b.count() > 0):
                y.append(b)
        print(y)
        return render(request, 'campus/sstu.html', {'y': y})
        """
        if request.method == "POST":
             jobid=request.POST.get("jobid")
             u=request.user.username
             x=len(job_pos.objects.filter(job_id=jobid,username=u))
             if(x==0):
                 s="enter correct job id"
                 return render(request, 'campus/sstu.html', {'y': y,'s':s})
             x=len(applied_jobs.objects.filter(job_id=jobid,company_id=u))
             if(x==0):
                s = "sorry no one applied"
                return render(request, 'campus/sstu.html', {'y': y, 's': s})
             tenth=request.POST.get("tenth")
             twth=request.POST.get("twth")
             Masters=request.POST.get("Masters")
             x = applied_jobs.objects.filter(job_id=jobid,company_id=u).values('student_id')
             y=[]
             print(x)
             y=[]
             print("the total number is",len(y))
             for i in x:
                 b=stu_details.objects.filter(class_10_cgpa__gte=tenth,class_12_percentage__gte=twth,cgpa_Masters__gte=Masters,username=i['student_id'])
                 if(b.count()>0):
                   y.append(b)
             print("the total number is",len(y))
             if(len(y)==0):
                 s = "requirements not satisfied"
                 return render(request, 'campus/sstu.html', {'y': y, 's': s})
             else:
                 print(y)
                 return render(request, 'campus/sstu.html', {'y': y, 's': s})
        else:
          return render(request, 'campus/sstu.html', {'y': y})
        """
    else:
        return HttpResponse("<h1>u r not logged in</h1>")


def stumail(request,opt):
    if request.user.is_authenticated and request.user.groups.filter(name='company').exists():
        if request.method=="POST":
            """
            recv=stu_details.objects.filter(username=opt)[0].email
            name=stu_details.objects.filter(username=opt)[0].name
            p=request.user.username
            p=comp_details.objects.filter(username=p)[0].company_name
            print(recv,p)
            subject="call letter from "+p
            body="Congratlations!!!"+str(name)+" you are selected for the interview ,the date for the interview will be anounced by your Placement Officer"
            email = EmailMessage(subject, body, to=[recv])
            email.send()
            """
            recv = stu_details.objects.filter(username=opt)[0].email
            print("Rec Mail : ", recv)
            #return HttpResponse("<h1>mail sent </h1>")
            return render(request, 'http://www.gmail.com')
        else:
            print("hiiiii")
            x=stu_details.objects.filter(username=opt)
            print(x)
            return render(request,'campus/showstudent.html',{'post':x[0]})

    else:
        return HttpResponse("<h1>u r not logged in</h1>")

def contact(request):
    if request.method == 'POST':
        form = contact(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'contact/success.html')
    return render(request, 'campus/contact.html')

def about(request):
    return render(request, 'campus/about.html')

